package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class AccountCreatedPage extends BasePage 

{

	public AccountCreatedPage(WebDriver driver)
	
	{
		super(driver);
		// TODO Auto-generated constructor stub
	}

	
	
	
	
	By accountCreated = By.xpath("//h2[@class='title text-center']//child::b");
	
	
	@FindBy (xpath="//a[@data-qa='continue-button']")
			WebElement continuetest;
	
	public void continueClick()
	{
		continuetest.click();
	}

	
	public boolean isAccCretedMsg() 
	{
		return isElementVisible(accountCreated);
	}
	
	

	
	
	
}
