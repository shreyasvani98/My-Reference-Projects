package StepdefsAnurodh;

import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import BaseAnurodh.TestBase;
import BaseAnurodh.TestUtil;
import PagesAnurodh.loginPage;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;


public class searchProducts extends TestBase {
	
	
	
	loginPage login;
	searchProducts sp;
	TestUtil testutil = new TestUtil();
	public searchProducts() {
		super();
	}
	
	
	@Before
	public void setup() {
		initialize();
		login = new loginPage();
		sp = new searchProducts();
	}
	
	
	@Given("User is on homepage")
	public void user_is_on_homepage() throws IOException {	
		driver.get("https://demo.opencart.com/");
		
	
	}
	
	
	@Given("logged in with {string} and {string}")
	public void logged_in_with_and(String string, String string2) {
	
		driver.findElement(By.xpath("//a[@class='dropdown-toggle']")).click();
		driver.findElement(By.xpath("//a[contains(text(), 'Login')]")).click();
		
		
        login = new loginPage();
		
		login.enterEmail(string);
		

		login.enterPassword(string2);
		
		login.clickLogin();
		

	}
	
	
	
	@When("clicking on the search box user should be able to search the product")
	public void clicking_on_the_search_box_user_should_be_able_to_search_the_product() throws IOException {
		
		  WebElement phonesearch = driver.findElement(By.xpath("//input[@type='text']"));
		   phonesearch.sendKeys("Phone");
		   
		   WebElement searchclick = driver.findElement(By.xpath("//button[@type='button' and @class='btn btn-default btn-lg']"));
		   searchclick.click();
		   testutil.takeScreenshotAtEndOfTest();
	
	}
     
	
	@When("navigated to particular product page")
	public void navigated_to_particular_product_page() {
		
		 driver.findElement(By.xpath("//img[@alt='iPhone']")).click();
	}		 
	  
    @After
    
	@When("Close the browser")
	public void close_the_browser() throws InterruptedException{
		
		Thread.sleep(2000);
		try {
			driver.quit();
		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}
	
	}

}
