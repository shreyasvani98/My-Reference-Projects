package StepdefsAnurodh;

import java.io.IOException;

import org.openqa.selenium.By;

import BaseAnurodh.TestBase;
import BaseAnurodh.TestUtil;
import PagesAnurodh.loginPage;
import io.cucumber.java.en.Then;


public class displayPreference extends TestBase{
	
	loginPage login = new loginPage();
	TestUtil testutil = new TestUtil();
	
	@Then("user should be able to view products in list format")
	public void user_should_be_able_to_view_products_in_list_format() throws IOException {
		
		driver.findElement(By.xpath("//button[@id='list-view']")).click();
		testutil.takeScreenshotAtEndOfTest();

	}

	@Then("user should be able to view products in grid format")
	public void user_should_be_able_to_view_products_in_grid_format() {
		
		driver.findElement(By.xpath("//button[@id='grid-view']")).click();
		

	}

}
