package StepdefsAnurodh;

import java.io.IOException;

import org.openqa.selenium.By;
import BaseAnurodh.TestBase;
import BaseAnurodh.TestUtil;
import PagesAnurodh.loginPage;
import io.cucumber.java.en.Then;


public class wishlist extends TestBase{
	
	loginPage login = new loginPage();
	TestUtil testutil = new TestUtil();
	
	@Then("user clicks on Add to wishlist button")
	public void user_clicks_on_Add_to_wishlist_button() {
		
		driver.findElement(By.xpath("//button[@type='button' and @data-original-title='Add to Wish List'] ")).click();

	}

	@Then("product is added to the wishlist")
	public void product_is_added_to_the_wishlist() throws IOException {
		driver.findElement(By.id("wishlist-total")).click();
		testutil.takeScreenshotAtEndOfTest();

	}

}
