package StepdefsAnurodh;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import BaseAnurodh.TestBase;
import BaseAnurodh.TestUtil;
import PagesAnurodh.loginPage;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
 

public class sortProducts  extends TestBase {
	
	loginPage login = new loginPage();
	TestUtil testutil = new TestUtil();
	
	@When("is on the particular product page")
	public void is_on_the_particular_product_page() {
		 String pageTitle = driver.getTitle();
		 System.out.println("Page Title: "+pageTitle);
		 Assert.assertEquals("Search - Phone", pageTitle);
	}
	
	@When("user selects Name\\(A-Z) from the drop-down menu")
	public void user_selects_Name_A_Z_from_the_drop_down_menu() throws IOException {
		
		Select az = new  Select(driver.findElement(By.cssSelector("select[id='input-sort']")));
		az.selectByVisibleText("Name (A - Z)");
		testutil.takeScreenshotAtEndOfTest();

	}

	@Then("user should be able to view products sorted according to name in ascending order")
	public void user_should_be_able_to_view_products_sorted_according_to_name_in_ascending_order() {
		System.out.println("Name (A - Z) from the dropdown has been selected");

	}

	@When("user selects Name\\(Z-A) from the drop-down menu")
	public void user_selects_Name_Z_A_from_the_drop_down_menu() throws IOException {
		
		Select za = new  Select(driver.findElement(By.cssSelector("select[id='input-sort']")));
		za.selectByVisibleText("Name (Z - A)");
		testutil.takeScreenshotAtEndOfTest();
	  
	}

	@Then("user should be able to view products sorted according to name in descending order")
	public void user_should_be_able_to_view_products_sorted_according_to_name_in_descending_order() {
		System.out.println("Name (Z - A) from the dropdown has been selected");
	
	}

	@When("user selects Price\\(Low>High) from the drop-down menu")
	public void user_selects_Price_Low_High_from_the_drop_down_menu() throws IOException {

		Select lh = new  Select(driver.findElement(By.cssSelector("select[id='input-sort']")));
		lh.selectByVisibleText("Price (Low > High)");
		testutil.takeScreenshotAtEndOfTest();
	  
	}

	@Then("user should be able to view products sorted according to price in ascending order")
	public void user_should_be_able_to_view_products_sorted_according_to_price_in_ascending_order() {
		
		System.out.println("Price (Low > High) from the dropdown has been selected");
	  
	}

	@When("user selects Price\\(High>Low) from the drop-down menu")
	public void user_selects_Price_High_Low_from_the_drop_down_menu() throws IOException {
		Select hl = new  Select(driver.findElement(By.cssSelector("select[id='input-sort']")));
		hl.selectByVisibleText("Price (High > Low)");
		testutil.takeScreenshotAtEndOfTest();
	   
	}

	@Then("user should be able to view products sorted according to price in descending order")
	public void user_should_be_able_to_view_products_sorted_according_to_price_in_descending_order() {
		
		System.out.println("Price (High > Low) from the dropdown has been selected");

	   
	}

}
