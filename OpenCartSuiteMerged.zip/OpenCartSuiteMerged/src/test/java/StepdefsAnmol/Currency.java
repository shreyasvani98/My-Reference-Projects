package StepdefsAnmol;

import java.io.IOException;

import org.testng.annotations.Test;

import BaseAnmol.TestBase;
import BaseAnmol.TestScreenShot;
import PagesAnmol.homepage;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class Currency extends TestBase
{
	
	homepage home = new homepage();
	TestScreenShot ScreenShot = new TestScreenShot();
	
	Currency currency;
	
	@Test
	@When("user click on Currency icon")
	public void user_click_on_Currency_icon() throws IOException 
	{
		
		home.UserClicksOnCurrencyIcon();
		ScreenShot.takeScreenshot();
		System.out.println("Currency icon clicked");
	}

	//@Ignore
	@Test
	@Then("user see the list of available currency")
	public void user_see_the_list_of_available_currency() throws IOException 
	{
		
		home.CurrencyList();
		ScreenShot.takeScreenshot();
		
	}
	
	//@Ignore
	@Test
	@When("user clicks on dollar currency")
	public void user_clicks_on_dollar_currency() throws IOException
	{
		
		home.SelectsDollar();
		ScreenShot.takeScreenshot();
			
	}
	
	//@Ignore
	@Test
	@Then("Currency of website should change to dollar")
	public void currency_of_website_should_change_to_dollar() throws IOException 
	{
	
		home.currencyToDollar();
		ScreenShot.takeScreenshot();
				
	}
	
	//@Ignore
	@Test
	@When("user clicks on euro currency")
	public void user_clicks_on_euro_currency() throws IOException 
	{
		
		home.SelectsEuro();
		ScreenShot.takeScreenshot();	
	}
	
	//@Ignore
	@Test	
	@Then("Currency of website should change to euro")
	public void currency_of_website_should_change_to_euro() throws IOException 
	{
	
		home.currencyToEuro();
		ScreenShot.takeScreenshot();
	}
	
	//@Ignore
	@Test
	@When("user clicks on pound currency")
	public void user_clicks_on_pound_currency() throws IOException 
	{
	
		home.SelectsPound();
		ScreenShot.takeScreenshot();
	}
	
	//@Ignore
	@Test
	@Then("Currency of website should change to pound")
	public void currency_of_website_should_change_to_pound() throws IOException 
	{
	
	  home.currencyToPounds();
	  ScreenShot.takeScreenshot();
	}

	}


