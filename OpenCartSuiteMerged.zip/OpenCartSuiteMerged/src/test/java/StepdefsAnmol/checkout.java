package StepdefsAnmol;

import java.io.IOException;

import org.testng.annotations.Test;

import BaseAnmol.TestBase;
import BaseAnmol.TestScreenShot;
import PagesAnmol.homepage;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class checkout extends TestBase 
{
	
	homepage home = new homepage();
	checkout checkoutobj;
	TestScreenShot ScreenShot = new TestScreenShot();
	
	@Test
	@Then("user adds a product to the cart")
	public void user_adds_a_product_to_the_cart() throws IOException 
	{
		
		home.addToCart();
		ScreenShot.takeScreenshot();
		System.out.println("Product added to cart successfully");
	  
	}
	
	@Test
	@When("user clicks on checkout icon")
	public void user_clicks_on_checkout_icon() 
	{
		
		home.clicksCheckOutIcon();
		System.out.println("Checkout Icon Clicked");
	  
	}
	
	@Test
	@Then("user should be navigated to the checkout page")
	public void user_should_be_navigated_to_the_checkout_page() throws IOException 
	{
	
		home.navToCheckoutPage();  //use assert
		ScreenShot.takeScreenshot();
		System.out.println("User is on the Checkout page");
	   
	}
	
	@Test
	@Then("user is able to see the checkout button")
	public void user_is_able_to_see_the_checkout_button() throws IOException 
	{
	
		home.seeCheckoutButton();
		ScreenShot.takeScreenshot();
		System.out.println("User is able to see the Checkout button");
			
	}
	
	}



