package StepdefsAnmol;

import java.io.IOException;

import org.testng.annotations.Test;

import BaseAnmol.TestBase;
import BaseAnmol.TestScreenShot;
import PagesAnmol.homepage;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class searchBox extends TestBase{
	
	homepage home = new homepage();
	TestScreenShot ScreenShot = new TestScreenShot();
	
	@Test
	@Given("search box is displayed")
	public void search_box_is_displayed() throws IOException 
	{
	
		home.searchBoxDisplay();
		ScreenShot.takeScreenshot();
			
	}
	
	@Test
	//@Ignore
	@Then("user is able to type in the search box")
	public void user_is_able_to_type_in_the_search_box() throws IOException 
	{
		
		home.typeInSearchbox();
		ScreenShot.takeScreenshot();
	
	}
	
	@Test
	//@Ignore
	@When("user clicks on the search button")
	public void user_clicks_on_the_search_button() 
	{
		
		home.searchButtonClicked();
		
	}
	
	@Test
	//@Ignore
	@Then("relevnt product is displayed")
	public void relevnt_product_is_displayed() throws IOException 
	{
		ScreenShot.takeScreenshot();
		//first product displayed here

	}

	}

