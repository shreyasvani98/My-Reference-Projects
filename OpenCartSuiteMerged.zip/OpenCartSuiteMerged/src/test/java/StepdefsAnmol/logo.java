package StepdefsAnmol;


import java.io.IOException;

import org.testng.annotations.Test;

import BaseAnmol.TestBase;
import BaseAnmol.TestScreenShot;
import PagesAnmol.homepage;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class logo extends TestBase {
	
	homepage home = new homepage();
	TestScreenShot ScreenShot = new TestScreenShot();
	
	@Test
	@When("user clicks on your store")
	public void user_clicks_on_your_store() 
	{
		   	
		home.UserClicksOnLogo();	
		System.out.println("User clicks on the logo");
	}

	//@Ignore
	@Test
	@Then("user should be navigated to the homepage")
	public void user_should_be_navigated_to_the_homepage() throws IOException 
	{
		
		home.navToHomepage();
		ScreenShot.takeScreenshot();
		
	}

}
