package StepdefsAnmol;


import java.io.IOException;

import org.testng.annotations.Test;

import BaseAnmol.TestBase;
import BaseAnmol.TestScreenShot;
import PagesAnmol.homepage;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class cart extends TestBase
{
	
	homepage home;   //creating an object of homepage
	cart cartobj;	//creating an object of cart	
	TestScreenShot ScreenShot = new TestScreenShot(); //creating an object of TestScreenShot and intializing it
	
	public cart()   // creating constructor
	{
	
		super();     // calling the constructor of Testbase
	
	}
	
	@Before			// this method will run before each test
	public void setup() // creating method setup
	{
		initialize();		// calling the initialize() method which is defined in the TestBase
		home = new homepage();  // intializing object of homepage
		cartobj = new cart();	// intializing object of cart
	}
	
	@Test	
	@Given("user is on the website")
	public void user_is_on_the_website() throws InterruptedException 
	{

			driver.get(prop.getProperty("get"));
			home.navToHomepage();
			
			System.out.println("(TestNG) User is on the OPEN CART website");
		 
			
	}
	
	@Test
	@When("user clicks on cart icon")
	public void user_clicks_on_cart_icon() 
	{
	
		home.cartIconClicked();
	}
	
	//@Ignore
	@Test
	@Then("user is able to see the cart")
	public void user_is_able_to_see_the_cart() throws IOException 
	{
		
		home.cartIsDisplayed();
		ScreenShot.takeScreenshot();
		
	}
	
	@After
	@Then("close the browser")
	public static void close_the_browser() throws InterruptedException
	{
		Thread.sleep(10000);
		try
		{
			driver.quit();
	    }
		catch(Exception e){
	            System.out.println(e.getMessage());
	    }
	}

}
