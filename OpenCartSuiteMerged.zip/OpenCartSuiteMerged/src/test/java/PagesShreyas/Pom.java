package PagesShreyas;


import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import BaseShreyas.TestBase;



public class Pom extends TestBase

{    
	

   //   object for the checkout feature(laptop)

  By Laptop = By.xpath( "//a[@href='https://demo.opencart.com/index.php?route=product/category&path=18']");

  By Show = By.xpath("//*[@id=\"menu\"]/div[2]/ul/li[2]/div/a");
  
  By  Sd = By.xpath("//img[@title='HP LP3065']");                          // use for both scrolling and for selecting product
  
  By  AddCart = By.xpath("//button[@type='button' and  @id='button-cart']"); // to add cart button and scroll down
  
  By  Cart  = By.xpath("//button[@type='button' and @data-toggle='dropdown']"); //cart button on top
  
  By CheckOutLink = By.xpath("//*[@id=\"cart\"]/ul/li[2]/div/p/a[2]");
  
  By  GuestCheckRad = By.xpath("//input[@type='radio' and @value='guest']"); // guest checkout option
  
  By  ContinueCheckout = By.xpath("//input[@type='button' and @value='Continue']");  // to continue the guest checkout
  
  By   FirstNamePay = By.xpath("//input[@name='firstname' and @id='input-payment-firstname']"); // first name for the checkout
  
  By   LastNamePay = By.xpath("//input[@id='input-payment-lastname']");                        //last name --||--
  
  By   EmailForPay = By.xpath("//input[@id='input-payment-email']");            // for the mail Id
  
  By TelPay  = By.xpath("//input[@id='input-payment-telephone']");           // for the telephone number 
  
  By  AddOne = By.xpath("//input[@id='input-payment-address-1']");         // to add the address line 1
  
  By AddTwo = By.xpath("//input[@id='input-payment-address-2']");        // addreas line 2
  
  By CityPay = By.xpath("//input[@id='input-payment-city']");          // city for adres
  
  By PostCode = By.xpath("//input[@id='input-payment-postcode']");   //postalcode address
  
  By CountryList= By.xpath("//select[@name='country_id' and @id='input-payment-country']"); // contry
  
  By Region = By.xpath("//select[@name='zone_id']");                                      // to select the region
		  
 By ConAdd      = By.xpath("//input[@type='button' and @id='button-guest']");            // continue after adding the address
  
  By ContAfterRegion = By.xpath("//input[@type='button' and @id='button-shipping-method']"); // continue after previous continue button
  
  By  AgreeCheckBox  = By.xpath("//input[@name='agree']");  // agreecheck box
  
  By  ConInpay     = By.xpath("//input[@type='button'and @id='button-payment-method']"); // payment continue button
   
  By ConfirmButton = By.xpath("//input[@type='button'and @id='button-confirm']"); // to confirm the button
 
  
  
  
  
  
  //   object for  login feature
  
  
  By  EmailId = By.id("input-email");
   
  By   pass = By.name("password");
  
  By   Login = By.xpath("//input[@type='submit' and @value='Login']");
  
  
  
  // objects for registration feature file.
  
  
 By  firstName = By.xpath("//input[@type='text' and  @class='form-control']");
 
 By  LastName = By.xpath("//input[@name='lastname']"); 
 
 By  Email   = By.xpath("//input[@type='email']");
 
 By   Tel    = By.xpath("//input[@type='tel']");
  
 By   PassSet = By.xpath("//input[@type='password' and  @id='input-password' ]");
 
 By   PassSetCon = By.xpath("//input[@type='password' and  @id='input-confirm' ]");
 
 By   CheckB     = By.xpath("//input[@type='checkbox' and @name='agree']");
 
 By   Continue = By .xpath("//input[@value='Continue']");
 
 
 // object for navigation feature ( bottom link to the registration) 
  
 By   BootLink  = By.xpath("/html/body/footer/div/div/div[4]/ul/li[1]/a");

 By   con   = By.xpath("//a[@class='btn btn-primary']");  // 
 
 
 
 // object for excelsheet
 
 UseExcelSheet Excel = new UseExcelSheet();
 
 
 
 
 
 
public Pom() 

{ 
	PageFactory.initElements(driver, this);
}




public void UserSelectsLaptop()     // to fine laptop

{
	driver.findElement(Laptop).click();
}



 public void ShowAll()  // to select show all option
 
 {
	 driver.findElement(Show).click();
 }
 
 
 
 
 public void ScrollDown()   // to scroll down at laptop
 
 {
	 WebElement scroll = driver.findElement(Sd);
	 Actions actions = new Actions(driver);
	 actions.moveToElement(scroll);
	 actions.perform();
 }
 
 
 public void EmailAndPass() throws IOException, InterruptedException
 {
	 driver.findElement(EmailId).sendKeys(Excel.readFromExcel("username"));
	 
//	 String Em  = driver.findElement(EmailId).getText();
//	 System.out.println("email id  is"+ Em);
     boolean shr = driver.findElement(EmailId).isDisplayed();
     Assert.assertTrue(shr);
     
    		 driver.findElement(pass).sendKeys(Excel.readFromExcel("password"));
    		 Thread.sleep(2000);
    		 
	 String Pass = driver.findElement(pass).getText();
		System.out.println("password is"+ Pass);
		
 }
 
 public void Login()
 {
	 driver.findElement(Login).click();
 }
 
   public void RegisterSteps()
   {
	   driver.findElement(firstName).sendKeys("rahul");
	   driver.findElement(LastName).sendKeys("gandhi");
	   driver.findElement(Email).sendKeys("rahulgandhi@gmail.com");
	   driver.findElement(Tel).sendKeys("9894888888");
	   driver.findElement( PassSet).sendKeys("password125");
	   driver.findElement(PassSetCon ).sendKeys("password125");
	   
	   driver.findElement(CheckB).click();
	   driver.findElement(Continue).click();
	   
	   
   }
 
   
   public void ScrollToBottHomePage()
   {
	   WebElement scroll = driver.findElement(BootLink);
		 Actions actions = new Actions(driver);
		 actions.moveToElement(scroll);
		 actions.perform();
   }
 
   public void BootLinkSelect()
   {
	   driver.findElement(BootLink).click();
   }
 
public void NavCon() 
{
	driver.findElement(con).click();
}
 
 
public void SelectProduct()
{
	 driver.findElement(Sd).click();
	
	 WebElement scroll = driver.findElement(AddCart);
	 Actions actions = new Actions(driver);
	 actions.moveToElement(scroll);
	 actions.perform();
	 
	 driver.findElement(AddCart).click();
	 driver.findElement(Cart).click();
	 driver.findElement(CheckOutLink).click();

}
 

public void AddressDetailsForOrder ()
{
	driver.findElement(GuestCheckRad).click();
    driver.findElement(ContinueCheckout).click();
    driver.findElement(FirstNamePay).sendKeys("shreyas sunil");
    driver.findElement(LastNamePay ).sendKeys("Vani");
    driver.findElement(EmailForPay).sendKeys("seleniumsprint@gmail.com");
	driver.findElement(TelPay).sendKeys("9988776655");
	driver.findElement(AddOne).sendKeys("mannat lands end , seafacing ,Bandra west");
	driver.findElement(AddTwo).sendKeys("near costal road");
	driver.findElement(CityPay).sendKeys("mumbai");
	driver.findElement(PostCode).sendKeys("400053");
	
	
	
	//driver.findElement(ConAdd).click();
	//driver.findElement(ContAfterRegion).click();
	//driver.findElement(AgreeCheckBox).click();
	//driver.findElement(ConInpay).click();
	//driver.findElement(ConfirmButton).click();
	
	
}
 

public void SelectCountry()
{
	WebElement Element = driver.findElement(CountryList);
    Select sel = new Select(Element);
    sel.selectByIndex(106);
}


public void SelectState()
{
	WebElement Element = driver.findElement(Region);
    Select sel = new Select(Element);
    sel.selectByValue("1493");
}


public void CopmleteOrder()
{
	 driver.findElement(ConAdd).click();
     driver.findElement(ContAfterRegion).click();
     driver.findElement(AgreeCheckBox).click();
	 driver.findElement(ConInpay).click();
	 driver.findElement(ConfirmButton).click();
	
	 
}


}
 


 
