package PagesAnmol;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import BaseAnmol.TestBase;
import ExcelSheet.ImplementExcelSheet;


public class homepage extends TestBase{    // creating class homepage that extends the TestBase class
	
	ImplementExcelSheet ImplementExcelSheet = new ImplementExcelSheet();
	
	// Storing the path for all the elements on homepage in a variable using By
	
	By link_Title = By.linkText("Your Store");      // using linkTest locator to locate element
	
	// using xpath relative locator to locate element
	By currency_icon = By.xpath("//div[@class='btn-group']");
	By currency_list = By.xpath("//ul[@class='dropdown-menu']");
	
	// locating elements by name
	By currency_dollar = By.name("USD");
	By currency_euro = By.name("EUR");
	By currency_pound = By.name("GBP");
	
	// using xpath absolute locator to locate element
	By price_dollar = By.xpath("/html/body/div[2]/div/div/div[2]/div[1]/div/div[2]/p[2]");
	By price_euro = By.xpath("/html/body/div[2]/div/div/div[2]/div[2]/div/div[2]/p[2]");
	By price_pounds = By.xpath("/html/body/div[2]/div/div/div[2]/div[3]/div/div[2]/p[2]");
	By add_to_cart = By.xpath("/html/body/div[2]/div/div/div[2]/div[1]/div/div[3]/button[1]");
	By checkout_icon = By.xpath("/html/body/nav/div/div[2]/ul/li[5]/a");
	By checkout_button = By.xpath("/html/body/div[2]/div[2]/div/div[3]/div[2]/a");
	By search_box = By.xpath("/html/body/header/div/div/div[2]/div/input");
	By search_type  = By.xpath("/html/body/header/div/div/div[2]/div/input");
	By search_butn_click = By.xpath("/html/body/header/div/div/div[2]/div/span/button");
	By cart_icon = By.xpath("/html/body/header/div/div/div[3]/div/button");
	By cart_visible = By.xpath("/html/body/header/div/div/div[3]/div/ul");
	

	public homepage() 
	{
		
		PageFactory.initElements(driver, this);          //initializing the PageFactory Elements
	
	}

	public void UserClicksOnLogo()
	{                      
	
		driver.findElement(link_Title).click();     // locating page logo and clicking on it

	}
	
	public void UserClicksOnCurrencyIcon() 
	{
	
		driver.findElement(currency_icon).click();	// locating currency icon and clicking on it
	
	}
	
	public void CurrencyList()
	{
	
		boolean issuccess = driver.findElement(currency_list).isDisplayed();   // Checking currency list is displayed or not
		System.out.println(issuccess);		// true means currency list is displayed and false means currency list is not displayed
	
	}
	
	public void SelectsDollar() 
	{
	
		driver.findElement(currency_dollar).click();  // locating dollar option and clicking on it
		System.out.println("Clicked Dollar");		
	
	}
	
	public void currencyToDollar() 
	{
	
		WebElement scroll = driver.findElement(price_dollar);  // Storing element location in scroll varialble 
		Actions actions = new Actions(driver); // creating and initilizing the action object
		actions.moveToElement(scroll);      	// moving to the desired element
		actions.perform();                  
		boolean success = driver.findElement(price_dollar).isDisplayed();  // checking if product currency is changed to dollar or not
		System.out.println("Currency changed to Dollar successfully ="+" " +success);
	
	}
	
	public void SelectsEuro()
	{
	
		driver.findElement(currency_euro).click();	// locating euro option and clicking on it
		System.out.println("Clicked Euro");
	
	}
	
	public void currencyToEuro() 
	{
	
		WebElement scroll = driver.findElement(price_euro);		// Storing element location in scroll varialble
		Actions actions = new Actions(driver);					// creating and initilizing the action object
		actions.moveToElement(scroll);							// moving to the desired element
		actions.perform();
		boolean success = driver.findElement(price_euro).isDisplayed(); // checking if product currency is changed to euro or not
		System.out.println("Currency changed to Euro successfully ="+" " + success);
	
	}
	
	public void SelectsPound() 
	{
	
		driver.findElement(currency_pound).click();		// locating pound option and clicking on it
		System.out.println("Clicked Pound");
	
	}
	
	public void currencyToPounds() 
	{
		
		WebElement scroll = driver.findElement(price_pounds);	// Storing element location in scroll varialble
		Actions actions = new Actions(driver);					// creating and initilizing the action object
		actions.moveToElement(scroll);							// moving to the desired element
		actions.perform();
		boolean success = driver.findElement(price_pounds).isDisplayed();	// checking if product currency is changed to pound or not
		System.out.println("Currency changed to Pounds successfully ="+" " + success);
	
	}
	
	public void addToCart() 
	{
		
		driver.findElement(add_to_cart).click();		// locating add to cart option and clicking on it
	
	}
	
	public void clicksCheckOutIcon() 
	{
		
		driver.findElement(checkout_icon).click();		// locating checkout icon and clicking on it
	
	}
	
	public void navToCheckoutPage() 
	{
		
		String get_Title = driver.getTitle();					// storing the title of the checkoutpage in a variable
		System.out.println(get_Title);							// printing the title of the page
		String Expected_Title = "Shopping Cart";						// storing the expected title of the page
		Assert.assertEquals(get_Title, Expected_Title); 						// checking if the actual title is equal to the excepted title using assert
	
	}
	
	public void seeCheckoutButton() 
	{
		
		WebElement scroll = driver.findElement(checkout_button);
		Actions actions = new Actions(driver);
		actions.moveToElement(scroll);
		actions.perform();
		boolean success = driver.findElement(checkout_button).isDisplayed();
		System.out.println("Checkout Button is displayed: "+success);
	
	}
	
	public void searchBoxDisplay() 
	{
	
		boolean success = driver.findElement(search_box).isDisplayed();
		System.out.println("Search Box is displayed: "+success);
	
	}
	
	public void typeInSearchbox() throws IOException 
	{
	
		driver.findElement(search_type).sendKeys(ImplementExcelSheet.readFromExcel("Text")); // locating search box and sending the value to it from the excel sheet
	
	}
	
	public void searchButtonClicked() 
	{
	
		driver.findElement(search_butn_click).click();			// locating search button and clicking on it
	
	}
	
	public void cartIconClicked() 
	{
	
		driver.findElement(cart_icon).click();					// locating cart icon and clicking on it
	
	}
	
	public void cartIsDisplayed() 
	{
	
		boolean success = driver.findElement(cart_visible).isDisplayed();
		System.out.println("Cart is visible"+" "+success);
	
	}
	
	public void navToHomepage()
	{
		String get_Title = driver.getTitle();
		System.out.println(get_Title);
		String Expected_Title ="Your Store";
		Assert.assertEquals(get_Title, Expected_Title);
		
	}
	
}
