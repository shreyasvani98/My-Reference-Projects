package Runner;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;

@CucumberOptions
(
	features = "src//test//resources//FeaturesAnurodh//",
	glue= {"StepdefsAnurodh"},
   //	dryRun=false, 
    plugin= {"pretty",  
					  "html:target/htmlReports.html",
					  "json:target/jsonReports.json",
					  
					  },
	monochrome=true

)
public class RunnerAnurodh extends AbstractTestNGCucumberTests
{
	
}
