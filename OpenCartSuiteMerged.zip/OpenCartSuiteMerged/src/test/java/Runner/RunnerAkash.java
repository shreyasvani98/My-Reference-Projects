package Runner;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;

@CucumberOptions(
		features="src//test//resources//FeaturesAkash//",
		glue={"StepdefsAkash"},
		dryRun=false,
		monochrome=true,
		plugin= {"pretty",
				"json:target/json-reports/Cucumber.json",
				"html:target/html-reports",
				"junit:target/junit-reports/Cucumber.xml"}
		//tags = {"@Test3"}
		)
public class RunnerAkash extends AbstractTestNGCucumberTests {

}
