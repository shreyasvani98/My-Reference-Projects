package Runner;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;

@CucumberOptions
(
	features = "src//test//resources//FeaturesShreyas",
	glue= {"StepdefsShreyas"},
//	dryRun=false, 
	monochrome=true,
//	tags= {""}
			plugin= {"pretty",  //gives info about what is executing in console
					  "html:target/htmlReports.html",
					  "json:target/jsonReports.json",
					  "junit:target/junitReports.xml"
					  }
			
	
)
public class RunnerShreyas extends AbstractTestNGCucumberTests
{
	
}
