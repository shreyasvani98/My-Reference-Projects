package StepdefsShreyas;

import java.io.IOException;

import org.testng.annotations.Test;

import BaseShreyas.Snap;
import BaseShreyas.TestBase;
import PagesShreyas.Pom;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class NavigationToRegF extends TestBase

{
	Pom chk = new Pom();
	Snap Scr = new Snap();
	
	
	
	@Test
	@When("user Scrolls down the homepage")                                                 // user scrolls down to homepage
	public void user_Scrolls_down_the_homepage() throws InterruptedException  
	{
		Thread.sleep(2000);
	   chk.ScrollToBottHomePage();
	}



	@Test
	@Then("user selects my account link")                                           // user selects my account link at bottom
	public void user_selects_my_account_link() 
	{
	  chk.BootLinkSelect();
	}



	@Test
	@Then("continues to new registration")                // user is navigated to registration page and continues registration
	
	
	public void continues_to_new_registration() throws InterruptedException, IOException 
	{
		chk.NavCon();
		Thread.sleep(2000);
		chk.RegisterSteps();
		Scr.takeScreenshotAtEndOfTest();
	}

}
