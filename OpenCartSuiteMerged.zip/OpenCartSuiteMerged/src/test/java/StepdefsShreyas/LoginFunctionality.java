package StepdefsShreyas;

import java.io.IOException;

import org.openqa.selenium.By;
import org.testng.annotations.Test;

import BaseShreyas.Snap;
import BaseShreyas.TestBase;
import PagesShreyas.Pom;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class LoginFunctionality extends TestBase
{

	Pom chk = new Pom();
	Snap Scr = new Snap();
	
	
	
	@Test
	@When("user selects login from my account dropdown")
	public void user_selects_login_from_my_account_dropdown()
	{
		driver.findElement(By.xpath("//a[@class='dropdown-toggle']")).click();  
		driver.findElement(By.xpath("//a[contains(text(), 'Login')]")).click();
	}





	@Test
	@When("user enters valid credentials")                                                  // user enters pre-registered login credentials 
	public void user_enters_valid_credentials() throws IOException, InterruptedException
	{
	   chk.EmailAndPass();
	   Scr.takeScreenshotAtEndOfTest();
	}





	@Test
	@Then("user should be logged into registered account")                                  // user continues with login 
	public void user_should_be_logged_into_registered_account() throws IOException 
	{   
	  chk.Login();
	  Scr.takeScreenshotAtEndOfTest();
	}
	
	
}
