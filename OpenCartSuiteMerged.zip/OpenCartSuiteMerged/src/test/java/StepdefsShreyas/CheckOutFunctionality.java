package StepdefsShreyas;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import BaseShreyas.Snap;
import BaseShreyas.TestBase;
import PagesShreyas.Pom;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class CheckOutFunctionality extends TestBase
{ 
	 
	
	
	Pom chk;
	Snap Scr = new Snap();
	
	
	CheckOutFunctionality Out ;
	
	public CheckOutFunctionality()
	{
		super();
	}
	
	@Before
	public void setup()
	{
		initialize();
		chk = new Pom();                                                 
		Out = new CheckOutFunctionality();
	    

		
	}
	
	
	
	@Test
	@Given("User is on homepage of OpenCart")                                  // User opens Homepage of opencart
	public void user_is_on_homepage_of_OpenCart() 
	{
		
	    driver.get("https://demo.opencart.com/");
	                                                     
	}
	
	
	
	@Test
	@When("user selects laptop from dropfown")                                              // user selects laptop from header
	public void user_selects_laptop_from_dropfown()
	{
		  chk.UserSelectsLaptop();
		  chk.ShowAll();
		  chk.ScrollDown();
	}
	
	
	
	
	
	@Test
	@When("adds the desired product to the cart")                                        // user selects desired product
	public void adds_the_desired_product_to_the_cart()
	{
		chk.SelectProduct();
	}
	
	
	@Test
	@When("selects checkout option")                                                     //user enters all data for delivery
	public void selects_checkout_option()
	{   
		chk.AddressDetailsForOrder();
		chk.SelectCountry();
		chk.SelectState();
		chk.CopmleteOrder();
	}
	
	@Then("order is placed")                                                             //order is placed
	public void order_is_placed() throws InterruptedException, IOException
	{
		Thread.sleep(2000);
		
		String actul = driver.getTitle();
		Assert.assertEquals(actul, "Your order has been placed!");
		Scr.takeScreenshotAtEndOfTest();
		
	}
	
	
	
	@After
	@Then("close the browser")                                                            //browser is closed
	public void close_the_browser()
	{
		
	    try {driver.quit();
    }
	    catch (Exception e) 
	    
    {
		   System.out.println(e.getMessage());
	}
	
	}
	
	
	
	
}
