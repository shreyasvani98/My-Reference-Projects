package StepdefsShreyas;

import java.io.IOException;

import org.openqa.selenium.By;
import org.testng.annotations.Test;

import BaseShreyas.Snap;
import BaseShreyas.TestBase;
import PagesShreyas.Pom;
import io.cucumber.java.en.When;

public class RegistrationFunctionality extends TestBase                    // check that pre-registered account is not accepted

{
	Pom chk = new Pom();
	Snap Scr = new Snap();
	
	
	@Test
	@When("user selects register option from my account dropdown")                             //user selects register from my account dropdown 
	public void user_selects_register_option_from_my_account_dropdown() 
	{

		driver.findElement(By.xpath("//a[@class='dropdown-toggle']")).click();
		driver.findElement(By.xpath("//a[contains(text(), 'Register')]")).click();
	}



	@Test
	@When("user followes registration procedure")                                               //user performs new registration
	public void user_followes_registration_procedure() throws IOException 

	{ 
		chk.RegisterSteps();
		Scr.takeScreenshotAtEndOfTest();
	}

	}
	
	

