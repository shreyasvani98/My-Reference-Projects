package StepdefsAkash;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.annotations.Test;

import BaseAkash.TestBase;
import BaseAkash.TestUtil;
import PagesAkash.Homepage;
import PagesAkash.UseExcelSheet;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;


public class Payment extends TestBase{

	Homepage homePage = new Homepage();
	Payment payment;
	TestUtil shot = new TestUtil();
	
	
	
	@Test
	@Given("User on Home page")
	public void user_on_Home_page() {
	    // Write code here that turns the phrase above into concrete actions
		String title = driver.getTitle();
	    Assert.assertEquals("Your Store", title);
	}

	@Test
	@Given("User selects the product of choice")
	public void user_selects_the_product_of_choice() {
	    // Write code here that turns the phrase above into concrete actions
		homePage.clicklaptop();
	    homePage.clickShowAll();
	    Select sel = new Select(driver.findElement(By.id(prop.getProperty("Show"))));
		sel.selectByIndex(1);
		homePage.clickproduct();
	}
	
	@Test
	@Given("adds it to the cart")
	public void adds_it_to_the_cart() {
	    // Write code here that turns the phrase above into concrete actions
		homePage.cleardeliverydate();
		homePage.enterdeliverydate("2021-06-24");
		homePage.clearquantity();
		homePage.enterquantity("1");
		homePage.clickaddtocart();
	}

	@Test
	@When("User selects checkout button")
	public void user_selects_checkout_button() {
	    // Write code here that turns the phrase above into concrete actions
		homePage.clickshoppingcart();
		homePage.clickcheckout();
	}
	
	@Test
	@Then("User goes to the checkout page")
	public void user_goes_to_the_checkout_page() {
	    // Write code here that turns the phrase above into concrete actions
		String actual = driver.getTitle();
	    Assert.assertEquals("Checkout", actual);
	    driver.navigate().refresh();
	}
	
	@Test
	@Given("User selects guest checkout as the checkout option")
	public void user_selects_guest_checkout_as_the_checkout_option() {
	    // Write code here that turns the phrase above into concrete actions
		homePage.clickguest();
	    homePage.clickcontinue1();
	}
	
	@Test
	@Given("User fills in the billing details")
	public void user_fills_in_the_billing_details() {
	    // Write code here that turns the phrase above into concrete actions
		homePage.enterfirstname("tom");
	    homePage.enterlastname("smith");
	    homePage.enteremail("tom12@yahoo.com");
	    homePage.entertelephone("2640652");
	    homePage.enteraddress("16, Mission Compound");
	    homePage.entercity("Saharanpur");
	    Select country = new Select(driver.findElement(By.xpath("//*[@id='input-payment-country']")));
	    country.selectByValue("99");
	    Select region = new Select(driver.findElement(By.xpath("//*[@id='input-payment-zone']")));
	    region.selectByValue("1505");

	}
	
	@Test
	@Given("User fills the delivery details and selects the delivery method")
	public void user_fills_the_delivery_details_and_selects_the_delivery_method() {
	    // Write code here that turns the phrase above into concrete actions
		 boolean status = driver.findElement(By.xpath("//input[@type='checkbox' and @name='shipping_address']")).isSelected();
		 Assert.assertTrue(status);
		 homePage.clickcontinue2();
		 boolean bool = driver.findElement(By.xpath("//input[@type='radio' and @name='shipping_method']")).isSelected();
		 Assert.assertTrue(bool);
		 homePage.clickcontinue3();
	}
	
	@Test
	@When("User selects the payment method")
	public void user_selects_the_payment_method() {
	    // Write code here that turns the phrase above into concrete actions
		boolean bhoot = driver.findElement(By.xpath("/html/body/div[2]/div/div/div/div[5]/div[2]/div/div[1]/label/input")).isSelected();
		Assert.assertTrue(bhoot);
		homePage.clickAgree();
		homePage.clickcontinue4();
	}
	
	@Test
	@Then("User navigates to the last step")
	public void user_navigates_to_the_last_step() throws IOException {
	    // Write code here that turns the phrase above into concrete actions
		boolean hoot = driver.findElement(By.xpath("//*[@id=\"accordion\"]/div[6]/div[1]/h4/a")).isDisplayed();
		Assert.assertTrue(hoot);
		shot.takeScreenshotAtEndOfTest();
	}
	
}
