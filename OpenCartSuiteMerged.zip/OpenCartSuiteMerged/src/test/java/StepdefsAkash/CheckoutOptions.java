package StepdefsAkash;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import BaseAkash.TestBase;
import BaseAkash.TestUtil;
import PagesAkash.Homepage;
import PagesAkash.UseExcelSheet;
import io.cucumber.java.Before;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;


public class CheckoutOptions extends TestBase {
	Homepage homePage  = new Homepage();
	CheckoutOptions checkout;
	UseExcelSheet Excel = new UseExcelSheet();
	TestUtil shot = new TestUtil();
	
	@Given("User is on the home page")
	public void user_is_on_the_home_page() throws IOException {
	    // Write code here that turns the phrase above into concrete actions
		String title = driver.getTitle();
	    Assert.assertEquals("Your Store", title);
	    shot.takeScreenshotAtEndOfTest();
	}

	@Given("User selects a product of choice")
	public void user_selects_a_product_of_choice() throws IOException {
	    // Write code here that turns the phrase above into concrete actions
		 	homePage.clicklaptop();
		    homePage.clickShowAll();
		    Select sel = new Select(driver.findElement(By.id(prop.getProperty("Show"))));
			sel.selectByIndex(1);
			homePage.clickproduct();
			shot.takeScreenshotAtEndOfTest();
	}

	@Given("Adds it to the cart")
	public void adds_it_to_the_cart() throws IOException {
	    // Write code here that turns the phrase above into concrete actions
		homePage.cleardeliverydate();
		homePage.enterdeliverydate("2021-06-24");
		homePage.clearquantity();
		homePage.enterquantity("1");
		homePage.clickaddtocart();
		shot.takeScreenshotAtEndOfTest();
	}

	@Given("User navigates to the checkout Page")
	public void user_navigates_to_the_checkout_Page() throws IOException {
	    // Write code here that turns the phrase above into concrete actions
		homePage.clickshoppingcart();
		homePage.clickcheckout();
		shot.takeScreenshotAtEndOfTest();
	}

	@When("User selects checkout options")
	public void user_selects_checkout_options() throws IOException {
	    // Write code here that turns the phrase above into concrete actions
	    driver.findElement(By.xpath("//*[@type='radio' and @value='register']")).click();
	    driver.findElement(By.xpath("//*[@id=\"input-email\"]")).sendKeys(Excel.readFromExcel("username"));
	    driver.findElement(By.xpath("//*[@id=\"input-password\"]")).sendKeys(Excel.readFromExcel("password"));
	    driver.findElement(By.xpath("//*[@id=\"button-login\"]")).click();
	    shot.takeScreenshotAtEndOfTest();
	}
	
	@When("User selects guest checkout options")
	public void user_selects_guest_checkout_options() throws IOException {
	    // Write code here that turns the phrase above into concrete actions
		homePage.clickguest();
	    homePage.clickcontinue1();
	    shot.takeScreenshotAtEndOfTest();
	}

	@Then("Billing details dropdown appears")
	public void billing_details_dropdown_appears() throws IOException {
	    // Write code here that turns the phrase above into concrete actions
	    boolean chor = driver.findElement(By.xpath("//*[@id=\"accordion\"]/div[2]/div[1]/h4/a")).isDisplayed();
	    Assert.assertTrue(chor);
	    shot.takeScreenshotAtEndOfTest();
	}

}
