package StepdefsAkash;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.annotations.Test;

import BaseAkash.TestBase;
import BaseAkash.TestUtil;
import PagesAkash.Homepage;
import PagesAkash.UseExcelSheet;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;


public class Confirm extends TestBase {
	
	Homepage homePage = new Homepage();
	Confirm confirm;
	TestUtil shot = new TestUtil();
	
	
	
	@Test
	@Given("User opens the website with valid url")
	public void user_opens_the_website_with_valid_url() {
	    // Write code here that turns the phrase above into concrete actions
		String title = driver.getTitle();
	    Assert.assertEquals("Your Store", title);
	}

	@Test
	@Given("User tries to look out for the product of choice")
	public void user_tries_to_look_out_for_the_product_of_choice() {
	    // Write code here that turns the phrase above into concrete actions
		homePage.clicklaptop();
	    homePage.clickShowAll();
	    Select sel = new Select(driver.findElement(By.id(prop.getProperty("Show"))));
		sel.selectByIndex(1);
		homePage.clickproduct();
	}

	@Test
	@Given("Add the selected to shopping cart")
	public void add_the_selected_to_shopping_cart() {
	    // Write code here that turns the phrase above into concrete actions
		homePage.cleardeliverydate();
		homePage.enterdeliverydate("2021-06-24");
		homePage.clearquantity();
		homePage.enterquantity("1");
		homePage.clickaddtocart();
	}

	@Test
	@When("User taps on checkout button")
	public void user_taps_on_checkout_button() {
	    // Write code here that turns the phrase above into concrete actions
		homePage.clickshoppingcart();
		homePage.clickcheckout();
	}

	@Test
	@Then("Checkout page loads")
	public void checkout_page_loads() {
	    // Write code here that turns the phrase above into concrete actions
		String actual = driver.getTitle();
	    Assert.assertEquals("Checkout", actual);
	}

	@Test
	@Given("User goes for guest checkout")
	public void user_goes_for_guest_checkout() {
	    // Write code here that turns the phrase above into concrete actions
		driver.navigate().refresh();
		homePage.clickguest();
	    homePage.clickcontinue1();
	}

	@Test
	@Given("User give inputs for billing details")
	public void user_give_inputs_for_billing_details() {
	    // Write code here that turns the phrase above into concrete actions
		homePage.enterfirstname("tom");
	    homePage.enterlastname("smith");
	    homePage.enteremail("tom12@yahoo.com");
	    homePage.entertelephone("2640652");
	    homePage.enteraddress("16, Mission Compound");
	    homePage.entercity("Saharanpur");
	    Select country = new Select(driver.findElement(By.xpath("//*[@id='input-payment-country']")));
	    country.selectByValue("99");
	    Select region = new Select(driver.findElement(By.xpath("//*[@id='input-payment-zone']")));
	    region.selectByValue("1505");
	}

	@Test
	@Given("User fills the delivery details and selects the delivery method and payment method")
	public void user_fills_the_delivery_details_and_selects_the_delivery_method_and_payment_method() {
	    // Write code here that turns the phrase above into concrete actions
	     boolean status = driver.findElement(By.xpath("//input[@type='checkbox' and @name='shipping_address']")).isSelected();
		 Assert.assertTrue(status);
		 homePage.clickcontinue2();
		 boolean bool = driver.findElement(By.xpath("//input[@type='radio' and @name='shipping_method']")).isSelected();
		 Assert.assertTrue(bool);
		 homePage.clickcontinue3();
		 boolean bhoot = driver.findElement(By.xpath("//*[@id=\"collapse-payment-method\"]/div/div[1]/label/input")).isSelected();
		 Assert.assertTrue(bhoot);
		 homePage.clickAgree();
		 homePage.clickcontinue4();
	}

	@Test
	@When("User confirms the order")
	public void user_confirms_the_order() {
	    // Write code here that turns the phrase above into concrete actions
	    homePage.clickconfirm();
	}

	@Test
	@Then("Shows Your order has been placed!")
	public void shows_Your_order_has_been_placed() throws InterruptedException, IOException {
	    // Write code here that turns the phrase above into concrete actions
	    Thread.sleep(2000);
	    String page = driver.getTitle();
	    Assert.assertEquals("Your order has been placed!", page);
	    shot.takeScreenshotAtEndOfTest();
	}



}
