package StepdefsAkash;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.annotations.Test;

import BaseAkash.TestBase;
import BaseAkash.TestUtil;
import PagesAkash.Homepage;
import PagesAkash.UseExcelSheet;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;


public class DeliveryMethod extends TestBase {

	Homepage homePage = new Homepage();
	DeliveryMethod deliverymethod;
	TestUtil shot = new TestUtil();
	
	@Test
	@Given("User finds the website")
	public void user_finds_the_website() {
	    // Write code here that turns the phrase above into concrete actions
		String title = driver.getTitle();
	    Assert.assertEquals("Your Store", title);
	}

	@Test
	@Given("User browse for various products")
	public void user_browse_for_various_products() {
	    // Write code here that turns the phrase above into concrete actions
		homePage.clicklaptop();
	    homePage.clickShowAll();
	    Select sel = new Select(driver.findElement(By.id(prop.getProperty("Show"))));
		sel.selectByIndex(1);
	}

	@Test
	@Given("User view a product")
	public void user_view_a_product() {
	    // Write code here that turns the phrase above into concrete actions
		homePage.clickproduct();
	}

	@Test
	@Given("User adds it to the cart")
	public void user_adds_it_to_the_cart() {
	    // Write code here that turns the phrase above into concrete actions
		homePage.cleardeliverydate();
		homePage.enterdeliverydate("2021-06-24");
		homePage.clearquantity();
		homePage.enterquantity("1");
		homePage.clickaddtocart();

	}

	@Test
	@When("User navigates to the shopping cart page")
	public void user_navigates_to_the_shopping_cart_page() {
	    // Write code here that turns the phrase above into concrete actions
		 homePage.clickshoppingcart();
	}

	@Test
	@When("clicks on checkout button")
	public void clicks_on_checkout_button() {
	    // Write code here that turns the phrase above into concrete actions
		 homePage.clickcheckout();
	}

	@Test
	@Then("Checkout Webpage appears")
	public void checkout_Webpage_appears() {
	    // Write code here that turns the phrase above into concrete actions
		String actual = driver.getTitle();
	    Assert.assertEquals("Checkout", actual);
	}

	@Test
	@Given("User enters billing details")
	public void user_enters_billing_details() {
	    // Write code here that turns the phrase above into concrete actions
		homePage.clickguest();
	    homePage.clickcontinue1();
	    homePage.enterfirstname("tom");
	    homePage.enterlastname("smith");
	    homePage.enteremail("tom12@yahoo.com");
	    homePage.entertelephone("2640652");
	    homePage.enteraddress("16, Mission Compound");
	    homePage.entercity("Saharanpur");
	    Select country = new Select(driver.findElement(By.xpath("//*[@id='input-payment-country']")));
	    country.selectByValue("99");
	    Select region = new Select(driver.findElement(By.xpath("//*[@id='input-payment-zone']")));
	    region.selectByValue("1505");
	}

	@Test
	@Given("User updates the delivery details")
	public void user_updates_the_delivery_details() {
	    // Write code here that turns the phrase above into concrete actions
		 boolean status = driver.findElement(By.xpath("//input[@type='checkbox' and @name='shipping_address']")).isSelected();
		 Assert.assertTrue(status);
		 homePage.clickcontinue2();
	}

	@Test
	@When("User selects the delivery method")
	public void user_selects_the_delivery_method() {
	    // Write code here that turns the phrase above into concrete actions
		boolean bool = driver.findElement(By.xpath("//input[@type='radio' and @name='shipping_method']")).isSelected();
		Assert.assertTrue(bool);
		homePage.clickcontinue3();
	}

	@Test
	@Then("user navigates to the payment page")
	public void user_navigates_to_the_payment_page() throws IOException {
	    // Write code here that turns the phrase above into concrete actions
	    boolean abc = driver.findElement(By.xpath("//*[@id=\"accordion\"]/div[5]/div[1]/h4/a")).isDisplayed();
	    Assert.assertTrue(abc);
	    shot.takeScreenshotAtEndOfTest();
	}


}
