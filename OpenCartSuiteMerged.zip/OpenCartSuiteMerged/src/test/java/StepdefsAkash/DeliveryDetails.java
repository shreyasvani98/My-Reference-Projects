package StepdefsAkash;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.annotations.Test;

import BaseAkash.TestBase;
import BaseAkash.TestUtil;
import PagesAkash.Homepage;
import PagesAkash.UseExcelSheet;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;


public class DeliveryDetails extends TestBase {
	
	Homepage homePage = new Homepage();
	DeliveryDetails deliverydetails;
	TestUtil shot = new TestUtil();
	


	@Test
	@Given("User goes to website to search for a product")
	public void user_goes_to_website_to_search_for_a_product() {
	    // Write code here that turns the phrase above into concrete actions
		String title = driver.getTitle();
	    Assert.assertEquals("Your Store", title);
	}

	@Test
	@Given("User gets a product and add it to cart")
	public void user_gets_a_product_and_add_it_to_cart() {
	    // Write code here that turns the phrase above into concrete actions
		homePage.clicklaptop();
	    homePage.clickShowAll();
	    Select sel = new Select(driver.findElement(By.id(prop.getProperty("Show"))));
		sel.selectByIndex(1);
		homePage.clickproduct();
		homePage.cleardeliverydate();
		homePage.enterdeliverydate("2021-06-24");
		homePage.clearquantity();
		homePage.enterquantity("1");
		homePage.clickaddtocart();
	}

	@Test
	@When("Checkout button")
	public void checkout_button() {
	    // Write code here that turns the phrase above into concrete actions
		 homePage.clickshoppingcart();
		 homePage.clickcheckout();
	}

	@Test
	@Then("Checkout page opens")
	public void checkout_page_opens() {
	    // Write code here that turns the phrase above into concrete actions
		String actual = driver.getTitle();
	    Assert.assertEquals("Checkout", actual);
	}

	@Test
	@Given("User selects checkout option")
	public void user_selects_checkout_option() {
	    // Write code here that turns the phrase above into concrete actions
		homePage.clickguest();
	    homePage.clickcontinue1();
	}

	@Test
	@Given("User fills the billing details")
	public void user_fills_the_billing_details() {
	    // Write code here that turns the phrase above into concrete actions
		homePage.enterfirstname("tom");
	    homePage.enterlastname("smith");
	    homePage.enteremail("tom12@yahoo.com");
	    homePage.entertelephone("2640652");
	    homePage.enteraddress("16, Mission Compound");
	    homePage.entercity("Saharanpur");
	    Select country = new Select(driver.findElement(By.xpath("//*[@id='input-payment-country']")));
	    country.selectByValue("99");
	    Select region = new Select(driver.findElement(By.xpath("//*[@id='input-payment-zone']")));
	    region.selectByValue("1505");
	}

	@Test
	@When("User clicks on the button to ensure that delivery address is same as billing address.")
	public void user_clicks_on_the_button_to_ensure_that_delivery_address_is_same_as_billing_address() {
	    // Write code here that turns the phrase above into concrete actions
		 boolean status = driver.findElement(By.xpath("//input[@type='checkbox' and @name='shipping_address']")).isSelected();
		 Assert.assertTrue(status);
		 homePage.clickcontinue2();
	}
	
	@Test
	@When("User enters  {string},{string},{string},{string},{string} and clicks on continue")
	public void user_enters_and_clicks_on_continue(String fname, String lname, String address, String city, String postcode) {
	    // Write code here that turns the phrase above into concrete actions
		driver.findElement(By.xpath("//input[@type='checkbox' and @name='shipping_address']")).click();
		homePage.clickcontinue2();
		 driver.findElement(By.id("input-shipping-firstname")).sendKeys(fname);
		 driver.findElement(By.id("input-shipping-lastname")).sendKeys(lname);
		 driver.findElement(By.id("input-shipping-address-1")).sendKeys(address);
		 driver.findElement(By.id("input-shipping-city")).sendKeys(city);
		 driver.findElement(By.id("input-shipping-postcode")).sendKeys(postcode);
		 Select dash = new Select(driver.findElement(By.xpath("//*[@id='input-shipping-country']")));
		 dash.selectByIndex(106);
		 Select zone = new Select(driver.findElement(By.xpath("//*[@id='input-shipping-zone']")));
		 zone.selectByValue("1505");
		 driver.findElement(By.id("button-guest-shipping")).click();
	}

	@Test
	@Then("User navigates to the next step of delivery method")
	public void user_navigates_to_the_next_step_of_delivery_method() throws IOException {
	    // Write code here that turns the phrase above into concrete actions
		boolean dropdown = driver.findElement(By.xpath("//*[@id=\"accordion\"]/div[4]/div[1]/h4/a")).isDisplayed();
	    Assert.assertTrue(dropdown);
	    shot.takeScreenshotAtEndOfTest();
	}
	
}
