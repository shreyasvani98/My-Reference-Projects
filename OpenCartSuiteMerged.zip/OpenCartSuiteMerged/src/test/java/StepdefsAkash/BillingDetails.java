package StepdefsAkash;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.annotations.Test;

import BaseAkash.TestBase;
import BaseAkash.TestUtil;
import PagesAkash.Homepage;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class BillingDetails extends TestBase {
	Homepage homePage;
	BillingDetails billingdetails;
	TestUtil shot = new TestUtil();
	
	public BillingDetails() {
		super();
	}
	
	@Before
	public void setup() {
		initialize();
		homePage = new Homepage();
		billingdetails = new BillingDetails();
	}
	
	@Test	
	@Given("User is on the home page and searches the product of choice")
	public void user_is_on_the_home_page_and_searches_the_product_of_choice() {
	    // Write code here that turns the phrase above into concrete actions
		String title = driver.getTitle();
	    Assert.assertEquals("Your Store", title);
	}
	
	@Test
	@Given("User selects the product of choice and adds it to the cart")
	public void user_selects_the_product_of_choice_and_adds_it_to_the_cart() {
	    // Write code here that turns the phrase above into concrete actions
	    homePage.clicklaptop();
	    homePage.clickShowAll();
	    Select sel = new Select(driver.findElement(By.id(prop.getProperty("Show"))));
		sel.selectByIndex(1);
		homePage.clickproduct();
		homePage.cleardeliverydate();
		homePage.enterdeliverydate("2021-06-24");
		homePage.clearquantity();
		homePage.enterquantity("1");
		homePage.clickaddtocart();
	}
	
	@Test
	@When("User clicks on checkout button")
	public void user_clicks_on_checkout_button() {
	    // Write code here that turns the phrase above into concrete actions
	    homePage.clickshoppingcart();
	    homePage.clickcheckout();
	}
	
	@Test
	@Then("User navigates to the checkout page")
	public void user_navigates_to_the_checkout_page() {
	    // Write code here that turns the phrase above into concrete actions
	    String actual = driver.getTitle();
	    Assert.assertEquals("Checkout", actual);
	}
	
	@Test
	@Given("User selects guest checkout as the checkout option and clicks on continue")
	public void user_selects_guest_checkout_as_the_checkout_option_and_clicks_on_continue() {
	    // Write code here that turns the phrase above into concrete actions
		driver.navigate().refresh();
	    homePage.clickguest();
	    homePage.clickcontinue1();
	}
	
	@Test
	@When("User enters {string},{string},{string},{string},{string},{string},{string} and clicks on continue")
	public void user_enters_and_clicks_on_continue(String string, String string2, String string3, String string4, String string5, String string6, String string7) throws IOException {
	    // Write code here that turns the phrase above into concrete actions
	    homePage.enterfirstname("tom");
	    homePage.enterlastname("smith");
	    homePage.enteremail("tom12@yahoo.com");
	    homePage.entertelephone("2640652");
	    homePage.enteraddress("16, Mission Compound");
	    homePage.entercity("Saharanpur");
	    Select country = new Select(driver.findElement(By.xpath("//*[@id='input-payment-country']")));
	    country.selectByValue("99");
	    Select region = new Select(driver.findElement(By.xpath("//*[@id='input-payment-zone']")));
	    region.selectByValue("1505");
	    boolean status = driver.findElement(By.xpath("//input[@type='checkbox' and @name='shipping_address']")).isSelected();
	    Assert.assertTrue(status);
	    homePage.clickcontinue2();
	    shot.takeScreenshotAtEndOfTest();
	}
	
	@Test
	@Then("User is navigated to the next steps")
	public void user_is_navigated_to_the_next_steps() throws IOException {
	    // Write code here that turns the phrase above into concrete actions
	    boolean dropdown = driver.findElement(By.xpath("//*[@id=\"accordion\"]/div[4]/div[1]/h4/a")).isDisplayed();
	    Assert.assertTrue(dropdown);
	    shot.takeScreenshotAtEndOfTest();
	}
	
	@Test
	@After
	public void close_the_browser() throws InterruptedException {
	    // Write code here that turns the phrase above into concrete actions
		Thread.sleep(3000);
		try
		{
			driver.quit();
	        }catch(Exception e){
	            System.out.println(e.getMessage());
	    }
	}
}
