package PagesAnurodh;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import BaseAnurodh.TestBase;



public class loginPage extends TestBase {
	
	
	
	By email_id = By.id("input-email");
	
	By password_pw = By.id("input-password");
	
	By login_lg = By.xpath("//input[@type='submit']");
	
	
	public loginPage() {
		PageFactory.initElements(driver, this);
	}
	
	public void enterEmail(String emailid) {
		driver.findElement(email_id).sendKeys(emailid);
	}
	
	public void enterPassword(String password) {
		driver.findElement(password_pw).sendKeys(password);
	}
	
	public void clickLogin() {
		driver.findElement(login_lg).click();
	}

}
