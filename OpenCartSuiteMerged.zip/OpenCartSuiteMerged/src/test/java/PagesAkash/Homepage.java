package PagesAkash;

import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;



public class Homepage extends BaseAkash.TestBase {
	
	//Page Factory
	@FindBy(xpath="//a[@href='https://demo.opencart.com/index.php?route=product/category&path=18']")
	WebElement laptop;
	
	@FindBy(xpath="/html/body/div[1]/nav/div[2]/ul/li[2]/div/a")
	WebElement ShowAll;
	
	@FindBy(xpath="//*[@id=\"content\"]/div[4]/div[1]/div/div[2]/div[1]/h4/a")
	WebElement product;
	@FindBy(id="input-option225")
	WebElement enterdeliverydate;
	@FindBy(id="input-quantity")
	WebElement enterquantity;
	@FindBy(id="button-cart")
	WebElement addtocart;
	@FindBy(xpath="//a[@href='https://demo.opencart.com/index.php?route=checkout/cart']")
	WebElement ShoppingCart;
	@FindBy(xpath="//a[@href='https://demo.opencart.com/index.php?route=checkout/checkout' and @class='btn btn-primary']")
	WebElement checkout;
	@FindBy(xpath="//input[@type='radio'and @value='guest']")
	WebElement guest;
	@FindBy(xpath="//input[@id='button-account']")
	WebElement continue1;
	@FindBy(id="button-guest")
	WebElement continue2;
	@FindBy(id="button-shipping-method")
	WebElement continue3;
	@FindBy(xpath="//*[@id=\"collapse-payment-method\"]/div/div[2]/div/input[1]")
	WebElement Agree;
	@FindBy(xpath="//*[@id='button-payment-method']")
	WebElement continue4;
	@FindBy(xpath="//*[@id='button-confirm']")
	WebElement confirm;
	@FindBy(id="input-payment-firstname")
	WebElement fname;
	@FindBy(id="input-payment-lastname")
	WebElement lname;
	@FindBy(id="input-payment-email")
	WebElement email;
	@FindBy(id="input-payment-telephone")
	WebElement telephone;
	@FindBy(id="input-payment-address-1")
	WebElement address;
	@FindBy(id="input-payment-city")
	WebElement city;
	@FindBy(id="input-payment-postcode")
	WebElement pincode;
//	Actions
	public Homepage() {
		PageFactory.initElements(driver,this);
	}
	public void clicklaptop() {
		laptop.click();
	}
	public void clickShowAll() {
		ShowAll.click();
	}
	public void clickproduct() {
		product.click();
	}
	public void cleardeliverydate() {
		enterdeliverydate.clear();
	}
	public void clearquantity() {
		enterquantity.clear();
	}
	public void enterfirstname(String name1) {
		fname.sendKeys(name1);
	}
	public void enterlastname(String name2) {
		lname.sendKeys(name2);
	}
	public void enteremail(String mail) {
		email.sendKeys(mail);
	}
	public void entertelephone(String number) {
		telephone.sendKeys(number);
	}
	public void enteraddress(String address1) {
		address.sendKeys(address1);
	}
	public void entercity(String place) {
		city.sendKeys(place);
	}
	public void enterpostcode(String pin) {
		pincode.sendKeys(pin);
	}
	public void enterquantity(String qty) {
		enterquantity.sendKeys(qty);
	}
	public void clickaddtocart() {
		addtocart.click();
	}
	public void clickshoppingcart() {
		ShoppingCart.click();
	}
	public void clickcheckout() {
		checkout.click();
	}
	public void clickguest() {
		guest.click();
	}
	public void clickcontinue1() {
		continue1.click();
	}
	public void enterdeliverydate(String date) {
		enterdeliverydate.sendKeys(date);
	}
	public void clickcontinue2() {
		continue2.click();
	}
	public void clickcontinue3() {
		continue3.click();
	}
	public void clickAgree() {
		Agree.click();
	}
	public void clickcontinue4() {
		continue4.click();
	}
	public void clickconfirm() {
		confirm.click();
	}
}
