package BaseAnmol;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class TestBase 
{
	public static Properties prop;   //creating an object of Properties
	public static WebDriver driver;	 //creating an object of driver
	
	public TestBase()
	{
		prop = new Properties();   //initializing the object prop
		FileInputStream fin;	   //creating an object of FileInputStream
		
		String path = System.getProperty("user.dir")+"//src//test//resources//PropertiesAnmol//OC.properties"; //getting the path of OC.properties object repository
		
		// using try catch block to handle exceptions
		
		try                                           
		{
			fin = new FileInputStream(path);         //initializing the object fin
			prop.load(fin);
		}
		
		catch(FileNotFoundException e)              // catching FileNotFoundException
		{e.printStackTrace();}                      // catching IOException
		catch(IOException e)
		{e.printStackTrace();}
	}
	
	
	public static void initialize()     // creating method initialize
	{
		String browser = prop.getProperty("browser");   						// storing browser name in a variable
		
		if(browser.equalsIgnoreCase("chrome"))          						// checking if variable browser is assigned the value chrome
		{
			System.setProperty(prop.getProperty("webdriver"),prop.getProperty("driverpath"));   // getting the web driver and driver path from OC.properties 
			driver = new ChromeDriver();  										//initializing the chrome driver
		}
		
		driver.manage().window().maximize();  									//maximizing the browser window
		driver.manage().deleteAllCookies();   									// deleting cookies
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);  
		driver.manage().timeouts().pageLoadTimeout(10, TimeUnit.SECONDS);
	
	}
	
}
